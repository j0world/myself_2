The current state of myself 2. A visual novel focusing on life with autism and adhd.
